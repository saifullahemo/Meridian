"""
data/database.py
----------------
Universal SQLite database layer for Personal OS.
Handles all reading and writing for every module dynamically.
No hardcoded tables — everything is driven by modules.json schema.
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime


# ─────────────────────────────────────────────
#  Paths
# ─────────────────────────────────────────────

ROOT    = Path(__file__).parent.parent.parent
DB_PATH = ROOT / "data" / "personal_os.db"


# ─────────────────────────────────────────────
#  Connection
# ─────────────────────────────────────────────

def get_connection() -> sqlite3.Connection:
    """Get a SQLite connection with row factory enabled."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # rows behave like dicts
    conn.execute("PRAGMA journal_mode=WAL")  # better concurrent access
    return conn


# ─────────────────────────────────────────────
#  Table management
# ─────────────────────────────────────────────

def create_table(module_key: str, schema: dict):
    """
    Create a SQLite table for a module based on its schema.
    Safe to call multiple times — uses CREATE TABLE IF NOT EXISTS.

    Args:
        module_key: e.g. "jobs"
        schema:     The module schema dict from modules.json
    """
    fields     = schema.get("fields", [])
    type_map   = {
        "text":    "TEXT",
        "number":  "REAL",
        "date":    "TEXT",
        "enum":    "TEXT",
        "boolean": "INTEGER",
    }

    columns = ["id INTEGER PRIMARY KEY AUTOINCREMENT"]
    for field in fields:
        sql_type = type_map.get(field["type"], "TEXT")
        columns.append(f"{field['name']} {sql_type}")
    columns.append("created_at TEXT DEFAULT CURRENT_TIMESTAMP")
    columns.append("updated_at TEXT DEFAULT CURRENT_TIMESTAMP")

    sql = (
        f"CREATE TABLE IF NOT EXISTS {module_key} "
        f"({', '.join(columns)})"
    )

    with get_connection() as conn:
        conn.execute(sql)
        conn.commit()

    print(f"Table '{module_key}' ready.")


def table_exists(module_key: str) -> bool:
    """Check if a table exists in the database."""
    with get_connection() as conn:
        result = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (module_key,)
        ).fetchone()
    return result is not None


def add_column(module_key: str, field_name: str, field_type: str = "TEXT"):
    """Add a new column to an existing table."""
    if not table_exists(module_key):
        raise ValueError(f"Table '{module_key}' does not exist.")
    try:
        with get_connection() as conn:
            conn.execute(
                f"ALTER TABLE {module_key} ADD COLUMN {field_name} {field_type}"
            )
            conn.commit()
        print(f"Column '{field_name}' added to '{module_key}'.")
    except sqlite3.OperationalError as e:
        if "duplicate column" in str(e).lower():
            print(f"Column '{field_name}' already exists.")
        else:
            raise


def get_table_columns(module_key: str) -> list[str]:
    """Get all column names for a table."""
    with get_connection() as conn:
        result = conn.execute(
            f"PRAGMA table_info({module_key})"
        ).fetchall()
    return [row["name"] for row in result]


# ─────────────────────────────────────────────
#  CRUD operations
# ─────────────────────────────────────────────

def insert(module_key: str, data: dict) -> int:
    """
    Insert a new record into a module table.

    Args:
        module_key: e.g. "jobs"
        data:       Dict of field values e.g. {"company": "Micron", ...}

    Returns:
        The id of the inserted record.
    """
    if not table_exists(module_key):
        raise ValueError(
            f"Table '{module_key}' does not exist. "
            f"Create the module first."
        )

    # Only include columns that exist in the table
    columns     = get_table_columns(module_key)
    valid_data  = {k: v for k, v in data.items() if k in columns}

    # Add timestamps
    now = datetime.now().isoformat()
    valid_data["created_at"] = now
    valid_data["updated_at"] = now

    keys        = list(valid_data.keys())
    values      = list(valid_data.values())
    placeholders= ", ".join(["?"] * len(keys))
    columns_str = ", ".join(keys)

    sql = f"INSERT INTO {module_key} ({columns_str}) VALUES ({placeholders})"

    with get_connection() as conn:
        cursor = conn.execute(sql, values)
        conn.commit()
        return cursor.lastrowid


def select(
    module_key: str,
    filters: dict   = None,
    order_by: str   = "created_at DESC",
    limit: int      = 100,
    offset: int     = 0
) -> list[dict]:
    """
    Query records from a module table.

    Args:
        module_key: e.g. "jobs"
        filters:    Dict of exact match filters e.g. {"country": "Singapore"}
        order_by:   SQL ORDER BY clause
        limit:      Max records to return
        offset:     For pagination

    Returns:
        List of record dicts.
    """
    if not table_exists(module_key):
        return []

    sql    = f"SELECT * FROM {module_key}"
    values = []

    if filters:
        conditions = []
        for key, value in filters.items():
            if value is None:
                conditions.append(f"{key} IS NULL")
            elif isinstance(value, (list, tuple)):
                placeholders = ", ".join(["?"] * len(value))
                conditions.append(f"{key} IN ({placeholders})")
                values.extend(value)
            else:
                conditions.append(f"{key} = ?")
                values.append(value)
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)

    sql += f" ORDER BY {order_by} LIMIT {limit} OFFSET {offset}"

    with get_connection() as conn:
        rows = conn.execute(sql, values).fetchall()

    return [dict(row) for row in rows]


def select_one(module_key: str, record_id: int) -> dict | None:
    """Get a single record by id."""
    if not table_exists(module_key):
        return None

    with get_connection() as conn:
        row = conn.execute(
            f"SELECT * FROM {module_key} WHERE id = ?",
            (record_id,)
        ).fetchone()

    return dict(row) if row else None


def update(module_key: str, record_id: int, data: dict) -> bool:
    """
    Update an existing record.

    Args:
        module_key: e.g. "jobs"
        record_id:  The record id
        data:       Fields to update e.g. {"status": "interview"}

    Returns:
        True if updated, False if record not found.
    """
    if not table_exists(module_key):
        raise ValueError(f"Table '{module_key}' does not exist.")

    # Only update valid columns
    columns    = get_table_columns(module_key)
    valid_data = {k: v for k, v in data.items() if k in columns and k != "id"}
    valid_data["updated_at"] = datetime.now().isoformat()

    set_clause = ", ".join([f"{k} = ?" for k in valid_data.keys()])
    values     = list(valid_data.values()) + [record_id]

    with get_connection() as conn:
        cursor = conn.execute(
            f"UPDATE {module_key} SET {set_clause} WHERE id = ?",
            values
        )
        conn.commit()

    return cursor.rowcount > 0


def delete(module_key: str, record_id: int) -> bool:
    """
    Delete a record by id.

    Returns:
        True if deleted, False if not found.
    """
    if not table_exists(module_key):
        raise ValueError(f"Table '{module_key}' does not exist.")

    with get_connection() as conn:
        cursor = conn.execute(
            f"DELETE FROM {module_key} WHERE id = ?",
            (record_id,)
        )
        conn.commit()

    return cursor.rowcount > 0


def count(module_key: str, filters: dict = None) -> int:
    """Count records in a module, with optional filters."""
    if not table_exists(module_key):
        return 0

    sql    = f"SELECT COUNT(*) as total FROM {module_key}"
    values = []

    if filters:
        conditions = [f"{k} = ?" for k, v in filters.items()]
        values     = list(filters.values())
        sql       += " WHERE " + " AND ".join(conditions)

    with get_connection() as conn:
        result = conn.execute(sql, values).fetchone()

    return result["total"] if result else 0


def search_text(module_key: str, query: str, fields: list[str]) -> list[dict]:
    """
    Full text search across specified fields.

    Args:
        module_key: e.g. "jobs"
        query:      Search term
        fields:     Fields to search e.g. ["company", "position", "notes"]
    """
    if not table_exists(module_key):
        return []

    conditions = [f"{field} LIKE ?" for field in fields]
    values     = [f"%{query}%" for _ in fields]
    sql        = (
        f"SELECT * FROM {module_key} "
        f"WHERE {' OR '.join(conditions)} "
        f"ORDER BY created_at DESC LIMIT 50"
    )

    with get_connection() as conn:
        rows = conn.execute(sql, values).fetchall()

    return [dict(row) for row in rows]


def raw_query(sql: str, values: list = None) -> list[dict]:
    """
    Execute a raw SQL query. Use with care.
    Useful for complex queries the standard methods can't handle.
    """
    with get_connection() as conn:
        rows = conn.execute(sql, values or []).fetchall()
    return [dict(row) for row in rows]


# ─────────────────────────────────────────────
#  Initialise all module tables
# ─────────────────────────────────────────────

def init_all_tables():
    """
    Create tables for all modules defined in modules.json.
    Call this once at startup.
    """
    config_path = ROOT / "config" / "modules.json"
    with open(config_path, "r") as f:
        config = json.load(f)

    modules = config.get("modules", {})
    for module_key, schema in modules.items():
        create_table(module_key, schema)

    print(f"Initialised {len(modules)} module tables.")


# ─────────────────────────────────────────────
#  Quick test
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("Testing database...\n")

    # Test 1 — Init all tables
    print("Test 1: Initialise all tables")
    print("-" * 40)
    init_all_tables()

    # Test 2 — Insert a job record
    print("\nTest 2: Insert a job record")
    print("-" * 40)
    record_id = insert("jobs", {
        "company":      "Micron",
        "position":     "Process Engineer",
        "country":      "Singapore",
        "date_applied": "2026-05-04",
        "status":       "applied",
        "source":       "LinkedIn",
        "notes":        "Applied via LinkedIn easy apply"
    })
    print(f"  Inserted record id: {record_id}")

    # Test 3 — Read it back
    print("\nTest 3: Read the record back")
    print("-" * 40)
    record = select_one("jobs", record_id)
    print(f"  Company : {record['company']}")
    print(f"  Position: {record['position']}")
    print(f"  Status  : {record['status']}")
    print(f"  Created : {record['created_at']}")

    # Test 4 — Update it
    print("\nTest 4: Update status to 'interview'")
    print("-" * 40)
    updated = update("jobs", record_id, {"status": "interview"})
    record  = select_one("jobs", record_id)
    print(f"  Updated : {updated}")
    print(f"  Status  : {record['status']}")

    # Test 5 — Count records
    print("\nTest 5: Count all jobs")
    print("-" * 40)
    total = count("jobs")
    print(f"  Total jobs: {total}")

    # Test 6 — Delete it
    print("\nTest 6: Delete the record")
    print("-" * 40)
    deleted = delete("jobs", record_id)
    total   = count("jobs")
    print(f"  Deleted : {deleted}")
    print(f"  Total jobs after delete: {total}")
