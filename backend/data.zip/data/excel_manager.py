"""
data/excel_manager.py
---------------------
Keeps Excel files in sync with the SQLite database.
Every module has its own Excel file that stays up to date.
You can open, share, or send these files at any time.
"""

import json
from pathlib import Path
from datetime import datetime

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False
    print("openpyxl not installed. Run: pip3 install openpyxl")


# ─────────────────────────────────────────────
#  Paths
# ─────────────────────────────────────────────

ROOT      = Path(__file__).parent.parent.parent
EXCEL_DIR = ROOT / "data" / "excel"
CONFIG    = ROOT / "config" / "modules.json"


# ─────────────────────────────────────────────
#  Styling
# ─────────────────────────────────────────────

HEADER_FILL   = PatternFill("solid", fgColor="1F4E79") if HAS_OPENPYXL else None
HEADER_FONT   = Font(bold=True, color="FFFFFF", name="Arial", size=11) if HAS_OPENPYXL else None
ALT_ROW_FILL  = PatternFill("solid", fgColor="EBF3FB") if HAS_OPENPYXL else None
NORMAL_FONT   = Font(name="Arial", size=10) if HAS_OPENPYXL else None
CENTER_ALIGN  = Alignment(horizontal="center", vertical="center") if HAS_OPENPYXL else None
LEFT_ALIGN    = Alignment(horizontal="left", vertical="center", wrap_text=True) if HAS_OPENPYXL else None

def _thin_border():
    side = Side(style="thin", color="CCCCCC")
    return Border(left=side, right=side, top=side, bottom=side)


# ─────────────────────────────────────────────
#  Load config
# ─────────────────────────────────────────────

def _load_modules() -> dict:
    with open(CONFIG, "r") as f:
        return json.load(f).get("modules", {})


def _get_excel_path(module_key: str) -> Path:
    schema    = _load_modules().get(module_key, {})
    filename  = schema.get("excel_file", f"{module_key}.xlsx")
    EXCEL_DIR.mkdir(parents=True, exist_ok=True)
    return EXCEL_DIR / filename


# ─────────────────────────────────────────────
#  Create Excel file
# ─────────────────────────────────────────────

def create_excel(module_key: str):
    """
    Create a fresh Excel file for a module with styled headers.
    Called automatically when a new module is created.
    """
    if not HAS_OPENPYXL:
        return

    modules = _load_modules()
    schema  = modules.get(module_key)
    if not schema:
        raise ValueError(f"Module '{module_key}' not found in modules.json")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = schema.get("label", module_key)

    # Build headers
    headers = ["id"] + [f["name"] for f in schema.get("fields", [])] + ["created_at", "updated_at"]
    _write_headers(ws, headers)

    # Set column widths
    _set_column_widths(ws, headers)

    path = _get_excel_path(module_key)
    wb.save(path)
    print(f"Excel created: {path}")
    return path


def _write_headers(ws, headers: list):
    """Write styled header row."""
    for col, header in enumerate(headers, 1):
        cell             = ws.cell(row=1, column=col, value=header.replace("_", " ").title())
        cell.font        = HEADER_FONT
        cell.fill        = HEADER_FILL
        cell.alignment   = CENTER_ALIGN
        cell.border      = _thin_border()
    ws.row_dimensions[1].height = 25


def _set_column_widths(ws, headers: list):
    """Set reasonable column widths."""
    width_map = {
        "id": 6, "created_at": 18, "updated_at": 18,
        "notes": 40, "description": 40, "company": 20,
        "position": 25, "country": 15, "status": 15,
        "date": 15, "date_applied": 15,
    }
    for col, header in enumerate(headers, 1):
        width = width_map.get(header, 18)
        ws.column_dimensions[get_column_letter(col)].width = width


# ─────────────────────────────────────────────
#  Sync database → Excel
# ─────────────────────────────────────────────

def sync_module(module_key: str):
    """
    Full sync — rebuild Excel file from database.
    Use this to ensure Excel is always up to date.
    """
    if not HAS_OPENPYXL:
        return

    from backend.data import database

    modules = _load_modules()
    schema  = modules.get(module_key)
    if not schema:
        raise ValueError(f"Module '{module_key}' not found.")

    # Get all records from database
    records = database.select(module_key, limit=10000)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = schema.get("label", module_key)

    # Headers
    headers = ["id"] + [f["name"] for f in schema.get("fields", [])] + ["created_at", "updated_at"]
    _write_headers(ws, headers)
    _set_column_widths(ws, headers)

    # Data rows
    for row_idx, record in enumerate(records, 2):
        fill = ALT_ROW_FILL if row_idx % 2 == 0 else None
        for col_idx, header in enumerate(headers, 1):
            value         = record.get(header, "")
            cell          = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font     = NORMAL_FONT
            cell.border   = _thin_border()
            cell.alignment= LEFT_ALIGN
            if fill:
                cell.fill = fill

    # Freeze top row
    ws.freeze_panes = "A2"

    path = _get_excel_path(module_key)
    wb.save(path)
    print(f"Synced {len(records)} records → {path}")
    return path


def sync_all_modules():
    """Sync all modules to their Excel files."""
    modules = _load_modules()
    for module_key in modules:
        try:
            sync_module(module_key)
        except Exception as e:
            print(f"Error syncing {module_key}: {e}")


# ─────────────────────────────────────────────
#  Append a single row (faster than full sync)
# ─────────────────────────────────────────────

def append_row(module_key: str, record: dict):
    """
    Append a single record to the Excel file.
    Much faster than full sync for single inserts.
    """
    if not HAS_OPENPYXL:
        return

    path = _get_excel_path(module_key)

    # Create file if it doesn't exist
    if not path.exists():
        create_excel(module_key)

    modules = _load_modules()
    schema  = modules.get(module_key, {})
    headers = ["id"] + [f["name"] for f in schema.get("fields", [])] + ["created_at", "updated_at"]

    wb = openpyxl.load_workbook(path)
    ws = wb.active

    next_row = ws.max_row + 1
    fill     = ALT_ROW_FILL if next_row % 2 == 0 else None

    for col_idx, header in enumerate(headers, 1):
        value         = record.get(header, "")
        cell          = ws.cell(row=next_row, column=col_idx, value=value)
        cell.font     = NORMAL_FONT
        cell.border   = _thin_border()
        cell.alignment= LEFT_ALIGN
        if fill:
            cell.fill = fill

    wb.save(path)


# ─────────────────────────────────────────────
#  Export helpers
# ─────────────────────────────────────────────

def export_filtered(module_key: str, filters: dict, filename: str = None) -> Path:
    """
    Export a filtered subset of a module to a new Excel file.
    e.g. export all Singapore jobs to singapore_jobs.xlsx
    """
    if not HAS_OPENPYXL:
        return None

    from backend.data import database

    modules = _load_modules()
    schema  = modules.get(module_key)
    if not schema:
        raise ValueError(f"Module '{module_key}' not found.")

    records = database.select(module_key, filters=filters, limit=10000)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = schema.get("label", module_key)

    headers = ["id"] + [f["name"] for f in schema.get("fields", [])] + ["created_at"]
    _write_headers(ws, headers)
    _set_column_widths(ws, headers)

    for row_idx, record in enumerate(records, 2):
        fill = ALT_ROW_FILL if row_idx % 2 == 0 else None
        for col_idx, header in enumerate(headers, 1):
            value         = record.get(header, "")
            cell          = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font     = NORMAL_FONT
            cell.border   = _thin_border()
            cell.alignment= LEFT_ALIGN
            if fill:
                cell.fill = fill

    ws.freeze_panes = "A2"

    export_name = filename or f"{module_key}_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    export_path = EXCEL_DIR / export_name
    wb.save(export_path)
    print(f"Exported {len(records)} records → {export_path}")
    return export_path


# ─────────────────────────────────────────────
#  Quick test
# ─────────────────────────────────────────────

if __name__ == "__main__":
    from backend.data import database

    print("Testing Excel manager...\n")

    # Test 1 — Create Excel files for all modules
    print("Test 1: Create Excel files")
    print("-" * 40)
    modules = _load_modules()
    for module_key in modules:
        create_excel(module_key)

    # Test 2 — Insert some records and sync
    print("\nTest 2: Insert records and sync to Excel")
    print("-" * 40)
    database.init_all_tables()

    # Insert 3 job records
    jobs = [
        {"company": "Micron",  "position": "Process Engineer",  "country": "Singapore",
         "date_applied": "2026-05-01", "status": "applied",    "source": "LinkedIn"},
        {"company": "Apple",   "position": "iOS Engineer",      "country": "USA",
         "date_applied": "2026-05-02", "status": "interview",  "source": "Company site"},
        {"company": "Google",  "position": "ML Engineer",       "country": "Remote",
         "date_applied": "2026-05-03", "status": "responded",  "source": "Indeed"},
    ]
    for job in jobs:
        record_id = database.insert("jobs", job)
        append_row("jobs", database.select_one("jobs", record_id))
        print(f"  Inserted + appended: {job['company']} - {job['position']}")

    # Test 3 — Full sync
    print("\nTest 3: Full sync jobs → Excel")
    print("-" * 40)
    sync_module("jobs")

    # Test 4 — Export filtered
    print("\nTest 4: Export Singapore jobs only")
    print("-" * 40)
    export_filtered("jobs", {"country": "Singapore"}, "singapore_jobs.xlsx")

    print("\nAll tests passed.")
    print(f"Check your Excel files at: {EXCEL_DIR}")
